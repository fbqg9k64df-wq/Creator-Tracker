const CACHE='elijah-cos-v1';
self.addEventListener('install',e=>{e.waitUntil(caches.open(CACHE).then(c=>c.addAll(['./','./index.html','./manifest.json'])));self.skipWaiting();});
self.addEventListener('activate',e=>{e.waitUntil(caches.keys().then(ks=>Promise.all(ks.filter(k=>k!==CACHE).map(k=>caches.delete(k)))));self.clients.claim();});
self.addEventListener('fetch',e=>{e.respondWith(caches.match(e.request).then(r=>r||fetch(e.request).catch(()=>caches.match('./index.html'))));});
self.addEventListener('message',e=>{
  if(!e.data||e.data.type!=='TICK')return;
  const {h,m,day}=e.data;
  const days=['Sunday','Monday','Tuesday','Wednesday','Thursday','Friday','Saturday'];
  const today=days[day];
  const anchors={Wednesday:'Teaching Post 📖',Thursday:'Music · Creative 🎵',Saturday:'Real Life · Convo 🌅'};
  const isAnchor=anchors[today];
  const slots=[
    {h:8,m:0,icon:'🌅',title:'Morning Drop',body:isAnchor?`Rise up! Today is ${today} — post your ${anchors[today]} + daily story. Let's GO! 🕷️`:`Good morning Elijah! Daily story time. Stay on the wall 🕷️`},
    {h:12,m:0,icon:'☀️',title:'Midday Check-In',body:isAnchor?`Midday! ${today} anchor post + story — have you hit it yet? Keep swinging 🕸️`:`Midday check! Posted your story today? Keep the streak alive 🕸️`},
    {h:18,m:0,icon:'🌆',title:'Evening Reminder',body:isAnchor?`Evening! ${today}'s anchor post + story — finish strong. The crew is proud 🕷️`:`Evening reminder — daily story! One post closer to greatness 🔥`},
  ];
  for(const s of slots){
    if(h===s.h&&m===s.m){
      self.registration.showNotification(`Creator OS ${s.icon} ${s.title}`,{
        body:s.body,icon:'./icon.png',badge:'./icon.png',
        tag:'cos-'+s.title,renotify:true,vibrate:[100,60,100,60,200],
        actions:[{action:'open',title:'📲 Open App'},{action:'dismiss',title:'Got it ✓'}]
      });
    }
  }
});
self.addEventListener('notificationclick',e=>{e.notification.close();if(e.action!=='dismiss')e.waitUntil(clients.openWindow('./'));});
